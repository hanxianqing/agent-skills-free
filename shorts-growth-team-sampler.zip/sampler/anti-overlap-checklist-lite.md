# Anti-Overlap Checklist — Lite (Free Sampler)

## The rules

1. **Same topic, 3 days: banned.** Never publish the same topic twice within 3 days, no matter how hot it still is.
2. **Same topic, new angle: change at least 2 of 4.** Hook, footage, news point, format — change at least two. Changing one fact is not changing the angle.
3. **Check the last 3 videos** (topic + footage + format) before you publish.
4. **If the hottest topic fails the check, take the next hottest.** Never publish a repeat because "it is the hottest".

## The 57-view lesson

Our video #10 (GTA 6 Has NO Darts) was the same topic, same countdown-list format, and same trailer footage as video #7 (GTA 6 Made $3.79 BILLION in One Day), published one day later. Result: **57 views**, against #7's 505.

The same game with a different angle — #8 (three stories, Mandy meme, new footage) — got 947 views. The topic was not dead. The repetition was.

## Per-video check

- [ ] Same topic in the last 3 days? YES → stop, pick another topic.
- [ ] Same topic as a recent video? Hook changed? [ ] Footage changed? [ ] News point changed? [ ] Format changed? — need at least 2 checked.
- [ ] Same format as the previous video? YES → change format.

---

*The full pack includes the complete checklist, the exhausted-topic log, and the full teardown of the 57-view video. Full pack: Whop $27 · Gumroad $27 · Agensi $12.99.*
