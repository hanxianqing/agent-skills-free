# GEO Visibility Scorecard — Lite

*Condensed from the full `scorecard.md`. The full version adds the complete deduction table for every dimension. Score only what you checked; anything unchecked is "not checked", not a guess.*

**Grade bands:** 80–100 Strong · 60–79 Workable · 40–59 Weak · 0–39 Invisible.

## The 7 dimensions

### 1. Crawlability & Indexation (15)
Full marks: robots allows crawling and names the right sitemap; sitemap returns 200; canonicals point at the live domain; Search Console verified + sitemap submitted; real impressions in the last 28 days.
Biggest deductions: robots blocks crawling (−15); sitemap not 200 (−7); canonical points at the wrong domain (−5); GSC not verified (−4); sitemap not submitted (−3).

### 2. Structured Data (15)
Full marks: every key page carries JSON-LD; homepage has `WebSite` + `Organization`; every visible Q&A is mirrored 1:1 in a `FAQPage` block; tool/calculator pages carry their own type (`SoftwareApplication` / `WebApplication`).
Biggest deductions: no JSON-LD on the homepage (−10); FAQPage covers fewer than half the visible Q&As (−5); no `WebSite` (−2); no `Organization` (−2); no specific type on tool pages (−3).

### 3. FAQ Coverage (15)
Full marks: at least 5 real customer questions per key page, answered directly (answer first, explanation second), in the customer's words.
Biggest deductions: fewer than 3 Q&As (−6); answers bury the answer (−3); a question answered with "contact us" and nothing else (−3 each).

### 4. Citation-Ready Content (15)
Full marks: at least 3 specific, checkable facts on the homepage (counts, prices, dates) with the basis shown; a comparison table against named alternatives; one short paragraph that directly answers the site's core question and can be quoted whole.
Biggest deductions: no specific numbers, only adjectives (−7); numbers undated and unsourced (−4); no comparison table (−3); no quotable answer paragraph (−3).

### 5. Brand & Entity Clarity (10)
Full marks: one spelling of the brand, everywhere; an About page and a contact route; `Organization` schema with `sameAs` links; a brand search returns this site, not a same-name competitor.
Biggest deductions: a same-name competitor owns the brand search (−4); no About page and no contact route (−2); no `Organization` schema (−2).

### 6. Titles & Summaries (15)
Full marks: title names the category + benefit in under 60 characters; meta description is a complete benefit-led sentence (120–160 characters); H1 states what the visitor gets; inner pages have unique titles.
Biggest deductions: title missing or over 70 characters (−5); meta description missing (−5); title is only the brand name (−4); H1 is only the brand name (−3); no Open Graph tags (−2).

### 7. Freshness & Depth (15)
Full marks: a visible update date within the last 14 days; a dated "new this week" section that actually changes; at least 10 substantive inner pages; every homepage link returns 200.
Biggest deductions: no visible update date (−4); fewer than 10 substantive inner pages (−4); inner pages are bare link lists (−3); a homepage link returns 404 (−3 each).

## Blank score table

| # | Dimension | Max | Score | One-sentence reason |
|---|---|---|---|---|
| 1 | Crawlability & Indexation | 15 | | |
| 2 | Structured Data | 15 | | |
| 3 | FAQ Coverage | 15 | | |
| 4 | Citation-Ready Content | 15 | | |
| 5 | Brand & Entity Clarity | 10 | | |
| 6 | Titles & Summaries | 15 | | |
| 7 | Freshness & Depth | 15 | | |
| | **Total** | **100** | | **Band:** |
