# Fix Checklist — Lite (Top 15)

*Condensed from the full `fix-checklist.md`. The full version adds the P0/P1/P2 structure, effort sizes, and copy-adapt JSON-LD templates. Work top to bottom — this list is already ordered by return.*

| # | Fix | Why it matters | Effort |
|---|---|---|---|
| 1 | Make `robots.txt` allow crawling and name the correct sitemap URL | If crawlers cannot read the site, nothing else matters | < 1 hour |
| 2 | Make `/sitemap.xml` return 200 and submit it in Search Console | The sitemap is how engines discover the pages | < 1 hour |
| 3 | Fix every canonical that points at the wrong domain | A wrong canonical tells engines the real site lives somewhere else | < 1 hour |
| 4 | Verify the Search Console property (meta-tag method) | Without it you are auditing blind — no impression data | < 1 hour |
| 5 | Add a `FAQPage` JSON-LD block that mirrors the visible Q&As 1:1 | This is the single most quotable structure on the page | < 1 hour |
| 6 | Give every key page a unique title (under 60 characters) and a 120–160 character meta description written as a sentence | Titles and descriptions are what engines show before anyone clicks | < 1 hour |
| 7 | Mirror every visible Q&A into the schema — count visible questions vs `Question` objects and close the gap | A FAQ the engine cannot read as data is just decoration | < 1 hour |
| 8 | Add `WebSite` + `Organization` schema with `sameAs` links to the brand's directory listings | Tells engines the brand is one entity, not a coincidence of words | < 1 hour |
| 9 | Give each tool / calculator page its own schema type (`SoftwareApplication` / `WebApplication`) | Inner pages without a type are invisible as tools | Half a day |
| 10 | Write a 2–3 sentence paragraph near the top of the homepage that directly answers the site's core question | This is the paragraph an AI answer lifts verbatim | < 1 hour |
| 11 | Date and source every number on the homepage — delete numbers you cannot source | Undated numbers are unquotable; AI engines skip them | < 1 hour |
| 12 | Add a comparison table against 2–3 named alternatives, dated | Comparisons are the most-cited content shape on the web | Half a day |
| 13 | Rewrite titles to answer the question (category + benefit), not just the brand name | A title that is only the brand name answers nothing | < 1 hour |
| 14 | Fix the brand collision: add a distinguishing word to the title/H1, get listed in 2–3 directories under the exact brand name, add an About page linking them | If a same-name competitor owns the brand search, you lose citations you earned | Half a day + weeks to take effect |
| 15 | Add Open Graph tags (`og:title`, `og:description`, `og:type`, `og:image`) to every key page | Free, fast, and missing on more sites than you'd expect | < 1 hour |

**After these 15:** re-run the audit with the same questions and record the new score next to the old one. If the score did not move, the fix did not land — check the live page, not the file you edited.
