# Shorts Growth Team — Free Lite Sampler

Free in exchange for a review. If it helps your channel, leave a review and tell us which archetype you used first.

## What is in the sampler

- `hook-library-lite.md` — the 10 hook archetypes with a fill-in template for each. Write 6–10 hooks per video across different archetypes, then pick one.
- `anti-overlap-checklist-lite.md` — the 3-day rule and the angle-change test, plus the short version of the 57-view lesson.

## What is in the full pack (not in the sampler)

- 5 SKILL.md files: trend-scan, hook-library, edit-checklist, tiktok-native-cut, comment-reply — the full daily pipeline.
- The real hook examples: each archetype paired with a real hook from our channel and its actual view count (best 2,404, worst 57).
- The full anti-overlap checklist with the exhausted-topic log.
- Audio Card — mood → music → voice → mix → loudness, with 8 verified free tracks.
- Render Pitfalls — 10 bugs we actually hit, with fixes.
- Case Study #6 — full teardown of our best video (2,404 views).

Full pack: Whop $27 · Gumroad $27 · Agensi $12.99.

## Honest note

The channel this comes from has 5 subscribers and $0 in sales so far. This sampler is a shipping system, not an income promise.
