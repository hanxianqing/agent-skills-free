# Hook Library — Lite (Free Sampler)

Write 6–10 hooks per video, across different archetypes, then pick one. Never ship the first idea.

## The 10 archetypes

**1. Curiosity gap** — say the answer exists, don't give it.
Template: `[Surprising fact]. [Authority] just explained why.`

**2. Withheld suspense** — show the result, hide the list.
Template: `[Topic] is BACK — [number] things you need to know.`

**3. Stakes / consequence** — "Stop doing X, or you'll never get Y."
Template: `Stop [wasteful habit] one at a time.`

**4. Bold / contrarian** — take a defensible opposite position, then deliver on it.
Template: `[Beloved thing] is dead. [New thing] is here.`

**5. Direct call-out** — "If you're an X, this is for you."
Template: `[Topic] is OUT — [number] things you need to know.`

**6. Mistake / cost confession** — "I spent $X and Y months so you don't have to."
Template: `I spent [money] and [time] on [mistake]. You don't have to.`
Numbers are the point: a confession without a number is just a complaint.

**7. Numbers / list** — let a number do the work.
Template: `[Topic] made [huge number] in [short time].`

**8. In medias res** — start mid-action, explain later.
Template: `[Character] came for [ordinary thing]. He left with [absurd outcome].`

**9. Question / POV** — use sparingly, only when the question itself is sharp.
Template: `[Famous character] has a [shocking secret]?!`
A weak question ("Did you know...?") is worse than a statement.

**10. Social proof / results first** — "Everyone keeps asking how I did this."
Template: `[Topic] made [huge number] in [one day].`

## How to write a hook

1. Lead with impact, then curiosity, then a payoff preview.
2. Put the first 3–5 words on frame one as big text *and* say them out loud.
3. Keep it short. Cut the connectors.
4. Specific beats clever — concrete nouns, numbers, stakes.
5. The hook must be paid off in the video. An overpromising hook is worse than a weak one.

## What never works

Slow openings, self-introductions, logos, brand-first frames, vague benefits ("improve your content"), a hook that needs explaining, opening with a product name.

## Picking among your 6–10

1. Would a stranger stop for this in 1 second?
2. Does it promise something the video actually delivers?
3. Is it a different archetype from the last two videos?

---

*The full pack pairs each archetype with a real hook from our channel and its actual view count — best 2,404 views, worst 57 — plus the full hook-writing skill with the three failure modes. Full pack: Whop $27 · Gumroad $27 · Agensi $12.99.*
