# GEO Site Audit — Lite (Free Sampler)

**This is the free Lite version of the GEO Site Audit Skill.**
It contains the condensed scorecard and the 15 highest-return fixes — enough to run a first audit of your own site and see whether the full pack is worth it.

**Free in exchange for an honest review.** If this sampler helps you, please leave a review on the listing you got it from. If it doesn't, say that too — a specific complaint ("the FAQ check missed X") is more useful than a polite five stars.

**What the full pack adds:** the complete audit workflow with exact steps and test questions (`SKILL.md`), the full scorecard with deduction tables, the complete fix checklist (P0/P1/P2 with JSON-LD templates), the client report template, and two complete worked audits of live sites (LocalTools 80/100, PennyMath 75/100).

**What this sampler does NOT promise:** rankings, citations, traffic, or revenue. It measures visibility. Nothing in here guarantees an outcome.

---

## Files in this sampler

| File | What it is |
|---|---|
| `scorecard-lite.md` | The 7 dimensions, condensed: what full marks looks like, the biggest deductions, and a blank score table. |
| `fix-checklist-lite.md` | The 15 highest-return fixes, in order. |
